# Техническое задания на закупку базовых сборочных компонентов для «Держатель-Для-Сварочной-Горелки»

❗Для точной идентификации физической формы компонента смотри соответствующий STEP файл.

## Магниты
| Компонент                              | STEP   |   Количество (штук) | Ссылка для покупки        |
|:---------------------------------------|:-------|--------------------:|:--------------------------|
| Держатель-Для-Сварочной-Горелки магнит | True   |                   2 | https://ozon.ru/t/7GG68ot |

## ISO-Крепёж
| Наименование                                     | Тип                            |   Количество (штук) | Ссылка для покупки                                                                                                                                             |
|:-------------------------------------------------|:-------------------------------|--------------------:|:---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| болт шестигранный                                | ISO 4014 - M10 x 70 x 26-N     |                   2 | https://www.ozon.ru/product/bolt-m10-h-70-mm-1kg-shestigrannyy-otsinkovannyy-din-933-2545673143/?at=6WtZNlqLNu15DBpkU1XkqJ5TXg366wI5jLRwJh7N7w7W&sh=w7z-KazKlQ |
| винт с потайной головкой и крестообразным шлицем | ISO 7046-1 - M8 x 35 - Z - 35N |                   1 | https://www.ozon.ru/product/vint-m8-h-35-mm-potaynoy-30-sht-1804939507/?at=oZt6npq0Bh2XrnG6sQWXY83sN1zyrEU9nZ4lYI4yn4DE&sh=w7z-KQgUsg                          |
| гайка шестигранная                               | ISO - 4032 - M10 - W - N       |                   2 | https://www.ozon.ru/product/gayka-shestigrannaya-m10-100sht-din-934-otsinkovannaya-2967340027/?at=mqtkxL9yxFZyE2j0cGp8j9OSNW3yz1hGGxBVpf2ko4Dj&sh=w7z-KazKlQ   |
| гайка шестигранная c фланцем                     | ISO - 4161 - M10 - N           |                   2 | https://www.ozon.ru/product/gayka-s-flantsem-m10-otsinkovannaya-10-sht-2558956778/?at=ywtA1mpO1FZmw4kjCR2x2WAC4r2Y9PSlDXzPMuDg51jx&sh=w7z-KazKlQ               |
| гайка шестигранная c фланцем                     | ISO - 4161 - M8 - N            |                   1 | https://www.ozon.ru/product/gayka-s-flantsem-m10-otsinkovannaya-10-sht-2558956778/?at=ywtA1mpO1FZmw4kjCR2x2WAC4r2Y9PSlDXzPMuDg51jx&sh=w7z-KazKlQ               |
